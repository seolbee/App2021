package com.example.myapplication;

public class WebBookVO {
    public int id;
    public String title;
    public int book_num;
    public String date;
    public String size;
    public int expire;
}
